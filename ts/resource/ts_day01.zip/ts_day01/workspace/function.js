"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function implicitReturnFunc() {
    return 12234;
}
let implResult1 = implicitReturnFunc();
const implicitReturnFunc2 = () => {
    return 10 + "a";
};
let implResult2 = implicitReturnFunc2();
// 설명형 함수
function explicitReturnFunc() {
    return false;
}
const fun1 = explicitReturnFunc;
const fun2 = explicitReturnFunc();
const explicitReturnFunc2 = () => {
    return "some value";
};
const fun3 = explicitReturnFunc2;
const fun4 = explicitReturnFunc2();
// 매개 변수
function funcWithParams(x, y, z) {
    return x + y + z;
}
const func5 = funcWithParams(10, 20, 10);
const funcWithParams2 = (x, z, y) => {
    return x + y + z;
};
const func = funcWithParams2(10, 20, String(30));
// 옵셔널 ?
const funcWithOptional = (x, y, z) => {
    // 검증 
    if (y === undefined) {
        return x;
    }
    if (z === undefined) {
        return x + y;
    }
    return x + y + z;
};
console.log(funcWithOptional(10));
console.log(funcWithOptional(10, 20));
console.log(funcWithOptional(10, 30, 40));
//# sourceMappingURL=function.js.map