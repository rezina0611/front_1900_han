// 이름, 나이, 취미를 변수에 담아서 콘솔에 출력하세요
// ex) 저의 이름은 '홍길동'이고, 나이는 'OO'살, 취미는 'OOOO'입니다.
// 세미콜론(;): 문장의 종료를 의미
let name = "홍길동"; 
let _age = 20; 
let $hobby = "잠자기";
// let result = '저의 이름은 ' + name + '이고, 나이는 ' + age + '살, 취미는 ' + hobby + '입니다.'

// console.log(result)

// 상수
const money = 10000;
// money = 1000;
console.log(money + 1000)