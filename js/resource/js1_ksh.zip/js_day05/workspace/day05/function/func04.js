let str1 = "javascript"
// 프로퍼티
console.log(str1.length)

function printA(str1){
    for(let i = 0; i < str1.length; i++){
        if(str1[i] === 'a'){
            console.log(str1[i])
        }
    }
}

printA("adjmkaskldjawkldjakljds")