// 함수 -> 뭐 할래
// 즉시 실행 함수 ()()
// (() => {
//   console.log("출력")
// })();

// (function(){
//   console.log("출력2")
// })();

// 콜백 함수
// 두 수를 받아서 두 수를 출력하기
const add = (num1, num2, callback) => {
  callback(num1 + num2)
}

const print = (value) => {
  console.log(value)
}

add(10, 20, print)
add(10, 20, (result) => {console.log(result)})
