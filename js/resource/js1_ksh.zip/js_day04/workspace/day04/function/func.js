// 1. 이름을 받으면, 이름을 출력해주는 함수
function printName(name){
  console.log(name + "님")
}

printName("홍길동")
printName("장길동")
printName("김길동")

// 2. 두 수를 받으면, 두 수를 뺀 결과를 알려주는 함수
function subtract(num1, num2){
  return num1 - num2 
}

let result = subtract(1762, 327)
console.log(result)

