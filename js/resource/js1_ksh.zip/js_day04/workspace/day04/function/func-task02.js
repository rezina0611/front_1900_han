// 화살표 함수 실습
// 1) 성과 이름을 받으면 연결 후 "님"을 붙여주는 함수
// 1. const 상수
// 2. 이름을 짓는다
// 3. () => {} 함수를 정의한다.
// 4. 함수 로직을 작성한다.
const addNim = (lastName, firstName) => { return lastName + firstName + "님" }
const addNim2 = (lastName, firstName) => lastName + firstName + "님"

let name = addNim("홍", "길동")
console.log(name)

// 2) 두 수를 받아서 두 수 중 제일 큰 값을 알려주는 함수
const getMinAndMax = (num1, num2) => { 
  let result = ""
  if(num1 === num2) { // 같은 경우
    result = "두 수가 같습니다." 
  }else if(num1 > num2){ // num1이 큰 경우
    result = num1
  }else{ // num2가 큰 경우
    result = num2
  }
  return result
}

const getMinAndMax2 = (num1, num2) => num1 === num2 ? "두 수가 같습니다" : num1 > num2 ? num1 : num2

let max = getMinAndMax(10, 20)
console.log(max)

// 3) 홀수인지 짝수인지 출력해주는 함수
const getOddOrEven = (num) => {console.log(num % 2 === 0 ? "짝수" : "홀수")}
getOddOrEven(10)

