// 1. 성과 이름을 받아서 연결해주는 함수
// 선언
function getFullName(lastName, firstName){
  return lastName + firstName
}

// 사용
console.log(getFullName("김", "길동"))

// 2. 두 값을 더해서 출력해주는 함수
function sum(num1, num2){
  console.log(num1 + num2)
}

sum(10, 20)

// 3. 이름을 전달하면 5번 출력해주는 함수
function printName(name){
  for(let i = 0; i < 5; i++){
    console.log(name)
  }
}

printName("홍길동")

// 4. 이름을 전달하면 이름뒤에 "님"을 붙여주는 함수
function addNim(name){
  return name + "님"
}

let result3 = addNim("홍길동")
console.log(result3)
