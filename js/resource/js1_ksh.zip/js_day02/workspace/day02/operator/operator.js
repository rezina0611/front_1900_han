// 최우선 연산자 "()"
// console.log(10 * 2 + 3)
// console.log(10 * (2 + 3))

// 단항 연산자
// num1 = 10
// console.log(num1++)
// console.log(num1)
// console.log(++num1)

// !낫(not) 연산자
// console.log(true)
// console.log(!false)
// console.log(!0)

// 산술 연산자(+, -, *, /, %)
// 문자열 + 숫자형 -> 연결
// 숫자형 + 숫자형 -> 연산
// console.log("홍길동" + 10)
// console.log("10" + 10)
// console.log(20 + 10)
// console.log(10 - 7) // 연산
// console.log("ㄱ" - 10)
// console.log("50" - 10)

// console.log(10 % 2)

// 마음대로 숫자를 정해서,
// 그 숫자가 6의 배수라면 true, 아니라면 false를 출력하시오.
// 힌트: %, 그 외 연산자들...
// let num = 12381902389104
// console.log(num % 6)
// console.log(!(num % 6))

// let money = 100000000 
// money -= 100000 
// money /= 1000000
// money *= 100000
// money += 1000

// console.log(money)

// 관계 연산자
// let num1 = 10
// let num2 = 11

// console.log(10 > 5)
// console.log(num1 >= 10)
// console.log(11 < 11)

// console.log(num1 && num2)
// console.log(15 > 10 && 12 < 3)

// let a = 10

// console.log(false && a++)
// console.log(a)

// console.log(10 || false)
// console.log(false || 20 < 15)
// console.log(false || 20)


// 삼항 연산자
// console.log(20 > 40 ? "20이 큽니다." : "20이 작습니다")

// 삼항 연산자의 실습
// 실습 1)
// 어떤 값이 짝수라면 "짝수입니다." 홀수라면 "홀수입니다"를 출력하는 삼항식
let num = 0
num = 157483
let result = num % 2 === 0 ? "짝수입니다" : "홀수입니다"
console.log(result)

// 나쁜 예시
// let result2 = console.log(num % 2 === 0 ? "짝수입니다" : "홀수입니다")

// 실습 2)
// 어떤 값이 실수라면 "실수입니다." 정수라면 "정수입니다"를 출력하는 삼항식
// ex) 10.0 -> 정수라고 판단
// ex) 17 -> 정수라고 판단
// ex) 16.2 -> 실수라고 판단

// 첫 번째
// % 1 === 0
let num3 = 123.123
let isInteger = num3 % 1 === 0
let intString = "정수입니다"
let floatString = "실수입니다"

let result2 = isInteger ? intString : floatString
let result3 = num3 % 1 ? floatString : intString
// console.log(result2)
// console.log(result3)

// 두 번째
console.log(parseInt(123.999))
let num4 = 1234.1234
let num5 = parseInt(num4)
num4 === num5 ? intString : floatString

// 대입 연산자(=)
let data = 10

let data1 = 10 + 3 * 7 
let data2 = 0
console.log(data1)




