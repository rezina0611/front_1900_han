// 실습)
// 1. 이름, 국어점수, 수학점수, 영어점수, 과학점수
// 변수 또는 상수로 임의로 입력
let name = "홍길동"
let korScore = 60
let mathScore = 72
let engScore = 100
let scScore = 22

// 2. 총점과 평균 구하기
let totalScore = korScore + mathScore + engScore + scScore
let average = totalScore / 4
let pass = ""
let result = ""

// 3. 평균이 60점 이상이면 합격, 평균이 60점 미만이면 불합격, 0이면 재평가 - 출력
if(average >= 60){
  pass = "합격"
}else if(average < 60){
  pass = "불합격"
}else if(average === 0){
  pass = "재평가"
}else{
  pass = "채점 오류"
}

// 템플릿 리터럴(ES6)
// `${변수}`
result = `${name}님의 총 점은 ${totalScore}점이고, 평균은 ${average}점이므로 결과는 ${pass}입니다`
console.log(result)




