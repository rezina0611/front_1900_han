// 편하게 쓰려고
// for(let i = 0; i <= 10; i++){
//   console.log("홍길동")
//   console.log(i)
// }

// for문을 이용해서 실습
// 1) 1 ~ 10까지 출력
// for(let i = 0; i < 10; i++){
//   console.log(i + 1)
// }

// 2) 10 ~ 1까지 출력
// for(let i = 0; i < 10; i++){
//   console.log(10 - i)
// }

// 3) 1 ~ 10까지 모두 더한 누적값을 출력
// let total = 0
// for(let i = 0; i < 10; i++){
//   let num = i + 1
//   total += num
// }
// console.log(total)


// for(let i = 0; i < 10; i++){
//   let num = i + 1;
//   console.log(num)
//   if(num === 5){
//     break
//   }
// }

// for(let i = 0; i < 10; i++){
//   let num = i + 1;
//   if(num === 5){
//     continue
//   }
//   console.log(num)
// }