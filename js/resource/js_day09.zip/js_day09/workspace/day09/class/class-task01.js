// 학생의 클래스를 만들고
// 수학, 국어, 영어 점수를 입력 받아 학생의 총점과 평균을 출력하시오.
class Student{
    constructor(name, math, kor, eng){
        this.name = name;
        this.math = math;
        this.kor = kor;
        this.eng = eng;
        this.total = math + kor + eng;
        this.average = (this.total / 3).toFixed(2)
    }

    introduce(){
        console.log(`${this.name}님의 총 점은 ${this.total}점이고, 평균은 ${this.average}점입니다.`)
    }
}

const hong = new Student('홍길동', 10, 20, 100)
const jang = new Student('장보고', 100, 70, 85)
const lee = new Student('이순신', 77, 55, 47)

hong.introduce()
jang.introduce()
lee.introduce()