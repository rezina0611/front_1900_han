const movies = [
  {
    name: "체인소맨",
    price: "15000",
    detail: {
      time: '20251125',
      actor: "모름"
    }
  },
  {
    name: "위키드",
    price: "15000",
    detail: {
      time: '20251225',
      actor: ""
    }
  },
  {
    name: "컨저링",
    price: "13000",
    detail: {
      time: '20240104',
      ghost: true
    }
  },
]

// actor만 모두 콘솔에 출력하기
movies.forEach(({detail}) => { console.log(detail?.actor ?? "익명배우") })
movies.forEach(({detail}) => { console.log(detail?.actor || "익명배우") })