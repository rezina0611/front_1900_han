// 객체의 선언 
const user1 = new Object();
const user2 = new Object();
const user3 = new Object();
const user4 = {}

user1.name = "홍길동"
user2.name = "장보고"