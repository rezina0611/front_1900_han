// 변수의 선언
var age1
// 변수의 초기화
var age2 = 10
var age3 = "10"

// console.log(age1, typeof(age1))
// console.log(age2 + 10, typeof(age2)) // 정수 + 값 -> 연산
// console.log(age3 + 10, typeof(age3)) // 문자열 + 값 -> 연결

// console.log(age2 - 10)
// console.log(age3 - 10)
// console.log("ㄱ" - 10)

// 호이스팅
// var age4;
// console.log(age4)
// age4 = 1000

// console.log(age4)
// var age4 = 1000

// var 쓰지 말자!
// let (ES6) - 변수
// const (ES6) - 상수
const age4 = 10000;
age4 = 1000
age4 = 1000
age4 = 10000
age4 = 5000
age4 = 500
console.log(age4)


















































