// 주석(Ctrl + /)
// console.log("hello, world!😎")

console.log('싱글쿼터 또는 더블쿼터는 각 한 쌍씩 문자열로 표시합니다.')

// \n : new line, 개행 문자, 줄바꿈
// \t : tab, 위 아래 줄 간격 맞춰 띄기'
// \" : " 표현
// \' : ' 표현
// \\ : \ 표현
console.log("이름은 \"홍길동\"\n나이는 20살")
console.log("이름은 '홍길동'")
console.log('이름은 "홍길동"')
console.log('\t이름은 "홍길동"')