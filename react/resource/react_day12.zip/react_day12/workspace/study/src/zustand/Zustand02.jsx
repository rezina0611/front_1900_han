import React from 'react';

const Zustand02 = () => {
  return (
    <div>
      Zustand02
    </div>
  );
};

export default Zustand02;