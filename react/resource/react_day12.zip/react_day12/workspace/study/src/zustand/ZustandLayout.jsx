import React from 'react';
import { Outlet } from 'react-router-dom';
import useCountStore from '../store/useCountStore';

const ZustandLayout = () => {
  const {count} = useCountStore()
  return (
    <div>
      <p>{count}</p>
      <Outlet />
    </div>
  );
};

export default ZustandLayout;