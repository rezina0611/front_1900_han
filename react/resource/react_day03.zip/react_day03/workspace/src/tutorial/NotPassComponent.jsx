import React from 'react';

const NotPassComponent = () => {
  const notPass = "당첨 불가"
  return (
    <div>
      {notPass}
    </div>
  );
};

export default NotPassComponent;