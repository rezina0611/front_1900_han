import React from 'react';
import './App.css';
import Name2 from './ref/Name2';

function App() {
  return (
    <>
      <Name2 />
    </>
  );
}

export default App;
