import React from 'react';
import './App.css';
import Jsx01 from './tutorial/Jsx01';
import Jsx02 from './tutorial/Jsx02';
import Jsx03 from './tutorial/Jsx03';
import Jsx04 from './tutorial/Jsx04';
import Jsx05 from './tutorial/Jsx05';

function App() {
  return (
    <>
      {/* 
        <Jsx01 />
        <Jsx02 />
        <Jsx03 />
        <Jsx04 />
        <Jsx05 /> 
      */}
    </>
  );
}

export default App;
