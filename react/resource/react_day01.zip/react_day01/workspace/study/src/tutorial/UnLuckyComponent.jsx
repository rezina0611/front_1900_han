import React from 'react';

const UnLuckyComponent = () => {
  const unLukcy = "당첨 불가"
  return (
    <div>
      {unLukcy}
    </div>
  );
};

export default UnLuckyComponent;