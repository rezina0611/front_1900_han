import React from 'react';

const PassComponent = () => {
  const pass = "입장 가능"
  return (
    <p>
      {pass}
    </p>
  );
};

export default PassComponent;