import React from 'react';

const LuckyComponent = () => {
  const lucky = "당첨"

  return (
    <p>
      {lucky}
    </p>
  );
};

export default LuckyComponent;