import React, { useState } from 'react';

const Count = () => {

  // 상태를 바꾸는 React의 Hook함수
  // const [변수, 세터] = useState("초기값")
  const [number, setNumber] = useState(0)

  console.log("number", number)
  console.log("setNumber", setNumber)

  const decrease = () => { setNumber(number - 1) }
  const increase = () => { setNumber(number + 1) }

  return (
    <div>
      <button id="subtract" onClick={decrease}>-1</button>
      {number}
      <button id="sum" onClick={increase}>+1</button>
    </div>
  );
};

export default Count;