import React, { useState } from 'react';

const Person = () => {

  const [info, setInfo] = useState({
    name : "",
    age : 0
  })

  // 사용자가 이름을 입력했다면 name의 컬러를 블루로 변경하기
  // 사용자가 나이를 입력했다면 age의 폰트 사이즈를 30px로 변경하기
  // ex) 홍길동 -> 이름 -> 컬러 블루
  // ex) 20 -> 나이 -> 폰트사이즈 30px

  return (
    <div>
    
    </div>
  );
};

export default Person;