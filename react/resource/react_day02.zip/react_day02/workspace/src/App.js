import React from 'react';
import './App.css';
import Colors from './state/Colors';
import Hobby2 from './state/Hobby2';

function App() {
  return (
    <>
      <Hobby2 />
    </>
  );
}

export default App;
