import React from 'react';

const Food = ({name}) => <li>{name}</li>

export default Food;