import { createBrowserRouter } from "react-router-dom";
import Main from "../pages/main/Main";
import Intro from "../pages/intro/Intro";
import Detail from "../pages/detail/Detail";
import Introcude from "../pages/introduce/Introcude";
import PostContainer from "../pages/posts/PostContainer";
import Post from "../pages/posts/Post";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Main />
  },
  {
    path: "/intro",
    element: <Intro />
  },
  {
    path: "/detail",
    element: <Detail />
  },
  {
    path: "/introduce",
    element: <Introcude />
  },
  {
    path: "/posts",
    element: <PostContainer />
  },
  {
    path: "/posts/read/:id",
    element: <Post />
  }
])

export default router;