export default function Jsx02(){

  const name = "홍길동"

  return (
    <>
      <h1>{name}의 컴포넌트의 연산</h1>
      <p>
        {1 + 1}
      </p>
    </>
  )
}