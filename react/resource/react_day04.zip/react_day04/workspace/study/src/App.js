import React from 'react';
import './App.css';
import FoodContainer from './ref/expert/FoodContainer';

function App() {
  return (
    <>
      <FoodContainer />
    </>
  );
}

export default App;
