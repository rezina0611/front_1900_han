import { createContext } from 'react'

const CharContext = createContext({})

export default CharContext;