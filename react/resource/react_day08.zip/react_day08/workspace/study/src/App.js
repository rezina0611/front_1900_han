import React from 'react';
import './App.css';
import GlobalStyle from './styles/global';
import { ThemeProvider } from 'styled-components';
import theme from './styles/theme';
import FontContainer from './context/normal/FontContainer';

function App() {
  return (
    <>
      <ThemeProvider theme={theme}>
        <GlobalStyle /> {/* 삭제 하지 마세요. */}
        <FontContainer />
      </ThemeProvider>
    </>
  );
}

export default App;
