import { faComment } from '@fortawesome/free-solid-svg-icons';
import S from './style';

const Styled05 = () => {
  return (
    <div>
      <S.CommentIcon icon={faComment} beat />
    </div>
  );
};

export default Styled05;