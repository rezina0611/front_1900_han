import React from 'react';
import './App.css';
import SideEffectTask from './lifecycle/function/SideEffectTask';

function App() {
  return (
    <>
      <SideEffectTask />
    </>
  );
}

export default App;
