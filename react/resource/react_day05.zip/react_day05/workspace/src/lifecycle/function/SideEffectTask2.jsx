import React, { useEffect, useState } from 'react';

const SideEffectTask2 = () => {

  // 다음 페이지를 누르면 다음 10개를 조회
  // 이전 페이지를 누르면 이전 10개를 조회
  const [todos, setTodos] = useState([])

  useEffect(() => {
    const getTodos = async () => {
      const response = await fetch("https://jsonplaceholder.typicode.com/todos?_start=0&_limit=10")
      const datas = await response.json()
      setTodos(datas)
    }

    getTodos()
  }, [])
  console.log(todos)
  
  const todoList = todos.filter(({completed}) => !completed).map(({title}, i) => (
    <li key={i}>{title}</li>
  ))

  return (
    <ul>
      {todoList}
      <button>이전 페이지</button>
      <button>다음 페이지</button>
    </ul>
  );
};

export default SideEffectTask2;