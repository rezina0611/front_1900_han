import React from 'react';

const HomeChild = () => {
  return (
    <div>
      
    </div>
  );
};

export default HomeChild;