import React from 'react';

const Hobby = ({hobby}) => {
  return (
    <li>
      {hobby}
    </li>
  );
};

export default Hobby;