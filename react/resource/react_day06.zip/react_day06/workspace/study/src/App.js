import React from 'react';
import './App.css';
import Box from './pages/box/Box';

function App() {
  return (
    <>
      <Box />
    </>
  );
}

export default App;
