import React from 'react';
import BasicButton from '../../components/button/BasicButton';

const Styled06 = () => {
  return (
    <div>
      <h1>컴포넌트</h1>
      <BasicButton size={"medium"} shape={"small"} variant={"primary"} border={""} font={"h3"} color={"white"}>로그인</BasicButton>
      <BasicButton size={""} shape={""} variant={"sub"} border={""} font={""} color={""}>로그인</BasicButton>
      <BasicButton size={""} shape={""} variant={"white"} border={""} font={""} color={""}>로그인</BasicButton>
      <BasicButton size={""} shape={""} variant={""} border={""} font={""} color={""}>로그인</BasicButton>
    </div>
  );
};

export default Styled06;