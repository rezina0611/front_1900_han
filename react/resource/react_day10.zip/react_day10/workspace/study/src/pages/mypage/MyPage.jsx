import React from 'react';

const MyPage = () => {
  return (
    <div>
      마이페이지!
    </div>
  );
};

export default MyPage;