import React from 'react';

// JSX는 if문을 사용할 수 없기 때문에 삼항 연산자를 지원한다.
// 조건식 ? 참일 때 랜더링할 JSX : 거짓일 때 랜더링할 JSX
// 조건식 && 참일 때 랜더링할 JSX, 거짓이면 아무것도 출력되지 않는다.
// if문을 쓰지 않고 연산자로 값을 출력할 수 있다.
// if문은 JSX 내부에 {}안에서 사용할 수 없고,
// 함수 내부에서는 정상적으로 사용할 수 있다.

const Jsx04 = () => {
  
  const login = false;

  return (
    <>
      <h1>삼항연산자</h1>
      {login ? (
        <>
          <p>로그인 성공</p>
          <p>😎</p>
        </>
      ): (
        <>
          <p>로그인 실패</p>
          <p>😎</p>
        </>
      )}
    </>
  );
};

export default Jsx04;